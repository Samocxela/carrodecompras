

const Footer = () => {
  return (
    <div>
        <div>Samocxela Copyrigth ©️</div>
        <p>Todos los derechos reservados</p>
    </div>
  )
}

export default Footer